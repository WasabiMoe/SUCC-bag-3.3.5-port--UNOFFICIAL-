## Fork details ##

SUCC-bag ported for 3.3.5 client by Emillion and ChatGPT5.

I AM NOT THE ORIGINAL AUTHOR!! I just liked the addon and wanted to use it on 3.3.5 client.
I used ChatGPT for help porting it, (I am not a programmer lol).


![SUCCbag](https://user-images.githubusercontent.com/107083057/234946553-9c0dfd94-ef42-4c34-8b6d-e9b99732fa20.png)

# SUCC-bag
Sublime User Convenience Collection - player inventory and bank   

![succ-bag](https://cloud.githubusercontent.com/assets/17740865/23642754/f5d4baa6-02b1-11e7-89ad-db77a9b3a6c3.jpg)

Sorting feature with [Clean_Up](https://github.com/GryllsAddons/Clean_Up) addon

Configurations available at /succbag

